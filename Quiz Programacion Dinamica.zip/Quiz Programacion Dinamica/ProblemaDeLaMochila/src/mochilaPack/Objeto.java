package mochilaPack;

public class Objeto {

	int peso, beneficio;
	
	public Objeto(int peso, int beneficio) {
		this.peso = peso;
		this.beneficio = beneficio;
	}

	public int getPeso() {
		return peso;
	}

	public void setPeso(int peso) {
		this.peso = peso;
	}

	public int getBeneficio() {
		return beneficio;
	}

	public void setBeneficio(int beneficio) {
		this.beneficio = beneficio;
	}



}
